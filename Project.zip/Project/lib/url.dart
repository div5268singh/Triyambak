import 'package:flutter/material.dart';

class URL{
  final playStoreUrl = "https://play.google.com/store/apps/details?id=com.example.webview'";
  final appStoreUrl = "https://apps.apple.com/in/app/example-webview/id1519205640";
  final aboutUsUrl="https://www.google.co.in/";
  final privacyPolicyUrl="https://www.google.co.in/";
  final termsConditionsUrl="https://www.google.co.in/";
  final webViewUrl="https://epsilonitservice.com/";
}