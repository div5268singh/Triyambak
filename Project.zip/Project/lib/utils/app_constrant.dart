// google ad ids

const android_Google_banner = "ca-app-pub-3940256099942544/6300978111";
const android_Google_interstitial = "ca-app-pub-3940256099942544/1033173712";
const ios_Google_banner = "ca-app-pub-3940256099942544/2934735716";
const ios_Google_interstitial ="ca-app-pub-3940256099942544/4411468910";